/* APUE code examples .
 * :copyright: (c) 2016 by the huaxz1986@163.com.
 * :license: lgpl-3.0, see LICENSE for more details.
 */

/*
 *   第十章：信号
 *
 * 测试 abort 函数的用法
 *
 */
#ifndef ABORT_
#define ABORT_
/*!
 * \brief test_abort :测试 abort 函数的用法
 */
void test_abort();
#endif // ABORT_

