var searchData=
[
  ['threads',['threads',['../d1/da1/thread__detach_8c.html#ab5fee3d9b8f09c1ac442c5611e046413',1,'threads():&#160;thread_detach.c'],['../d7/d4e/thread__join_8c.html#a86feee586646c0065218bf293fc97ae7',1,'threads():&#160;thread_join.c']]]
];
