var searchData=
[
  ['struct_5fdata',['Struct_Data',['../d1/d41/struct_struct___data.html',1,'']]]
];
