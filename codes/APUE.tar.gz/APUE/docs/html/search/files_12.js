var searchData=
[
  ['wait_5fwaitpid_2ec',['wait_waitpid.c',['../d7/dd7/wait__waitpid_8c.html',1,'']]],
  ['wait_5fwaitpid_2eh',['wait_waitpid.h',['../d8/d4e/wait__waitpid_8h.html',1,'']]]
];
