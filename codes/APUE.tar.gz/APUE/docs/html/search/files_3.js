var searchData=
[
  ['dir_5foperations_2ec',['dir_operations.c',['../d8/dec/dir__operations_8c.html',1,'']]],
  ['dir_5foperations_2eh',['dir_operations.h',['../dd/d56/dir__operations_8h.html',1,'']]],
  ['dup_5fdup2_2ec',['dup_dup2.c',['../d6/d68/dup__dup2_8c.html',1,'']]],
  ['dup_5fdup2_2eh',['dup_dup2.h',['../dd/d2c/dup__dup2_8h.html',1,'']]]
];
