var searchData=
[
  ['global_5fint',['global_int',['../d5/db9/setjmp__longjmp_8c.html#a86bf3e45b97134e4d4be9ca6fc1947d8',1,'setjmp_longjmp.c']]]
];
